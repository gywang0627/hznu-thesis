$pdf_mode = 5;
$xelatex = 'xelatex -interaction=nonstopmode -halt-on-error -file-line-error -synctex=1 %O %S';
$bibtex = 'bibtex %O %B';
$max_repeat = 5;
$clean_ext = 'acn acr alg glg glo gls ist nav run.xml snm synctex.gz vrb xdv';

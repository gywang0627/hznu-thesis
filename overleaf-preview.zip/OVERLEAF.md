# Overleaf 使用说明

## 导入与编译

1. 在 Overleaf 首页选择 New Project → Upload Project，上传本压缩包。
2. 在项目设置中将 Main document 设为 main.tex，Compiler 设为 XeLaTeX。
3. 点击 Recompile 查看预览。本包默认 fonts=fandol，使用草稿字体。

## 规范字体

正式排版时，将有权使用的下列字体文件上传到 fonts/：

- simsun.ttc
- simhei.ttf
- simkai.ttf
- times.ttf
- timesbd.ttf
- timesi.ttf
- timesbi.ttf

文件名区分大小写。在 main.tex 中将 fonts=fandol 改为 fonts=files 后重新编译。
Fandol 与 TeX Gyre 是预览用替代字体，字形和断行与规范字体不同。

## 写作

封面信息在 thesis-info.tex 中填写；摘要位于 frontmatter/；正文位于 chapters/；
参考文献位于 references.bib；附录、成果与致谢位于 backmatter/。
新增章节后在 main.tex 中添加对应的 include 命令。

## 目录

main.tex、hznu-ai-thesis.cls、hznu-gbt7714-numerical.bst、thesis-info.tex、
references.bib 与 assets/、frontmatter/、chapters/、backmatter/、fonts/ 保持在同一项目根目录。
编译完成后从 PDF 预览区下载生成的 PDF。
